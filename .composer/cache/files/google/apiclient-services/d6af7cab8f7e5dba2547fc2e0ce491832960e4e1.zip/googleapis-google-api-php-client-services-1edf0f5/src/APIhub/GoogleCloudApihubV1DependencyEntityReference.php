<?php
/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

namespace Google\Service\APIhub;

class GoogleCloudApihubV1DependencyEntityReference extends \Google\Model
{
  /**
   * Output only. Display name of the entity.
   *
   * @var string
   */
  public $displayName;
  /**
   * The resource name of an external API in the API Hub. Format:
   * `projects/{project}/locations/{location}/externalApis/{external_api}`
   *
   * @var string
   */
  public $externalApiResourceName;
  /**
   * The resource name of an operation in the API Hub. Format: `projects/{projec
   * t}/locations/{location}/apis/{api}/versions/{version}/operations/{operation
   * }`
   *
   * @var string
   */
  public $operationResourceName;

  /**
   * Output only. Display name of the entity.
   *
   * @param string $displayName
   */
  public function setDisplayName($displayName)
  {
    $this->displayName = $displayName;
  }
  /**
   * @return string
   */
  public function getDisplayName()
  {
    return $this->displayName;
  }
  /**
   * The resource name of an external API in the API Hub. Format:
   * `projects/{project}/locations/{location}/externalApis/{external_api}`
   *
   * @param string $externalApiResourceName
   */
  public function setExternalApiResourceName($externalApiResourceName)
  {
    $this->externalApiResourceName = $externalApiResourceName;
  }
  /**
   * @return string
   */
  public function getExternalApiResourceName()
  {
    return $this->externalApiResourceName;
  }
  /**
   * The resource name of an operation in the API Hub. Format: `projects/{projec
   * t}/locations/{location}/apis/{api}/versions/{version}/operations/{operation
   * }`
   *
   * @param string $operationResourceName
   */
  public function setOperationResourceName($operationResourceName)
  {
    $this->operationResourceName = $operationResourceName;
  }
  /**
   * @return string
   */
  public function getOperationResourceName()
  {
    return $this->operationResourceName;
  }
}

// Adding a class alias for backwards compatibility with the previous class name.
class_alias(GoogleCloudApihubV1DependencyEntityReference::class, 'Google_Service_APIhub_GoogleCloudApihubV1DependencyEntityReference');
