<?php
/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

namespace Google\Service\APIhub;

class GoogleCloudApihubV1ManageAddonConfigRequest extends \Google\Model
{
  protected $configType = GoogleCloudApihubV1AddonConfig::class;
  protected $configDataType = '';

  /**
   * Required. The config of the addon to be managed. This config will replace
   * the config present in the addon. The type of the config should match the
   * config type already present in the addon.
   *
   * @param GoogleCloudApihubV1AddonConfig $config
   */
  public function setConfig(GoogleCloudApihubV1AddonConfig $config)
  {
    $this->config = $config;
  }
  /**
   * @return GoogleCloudApihubV1AddonConfig
   */
  public function getConfig()
  {
    return $this->config;
  }
}

// Adding a class alias for backwards compatibility with the previous class name.
class_alias(GoogleCloudApihubV1ManageAddonConfigRequest::class, 'Google_Service_APIhub_GoogleCloudApihubV1ManageAddonConfigRequest');
